"""
model_fixes.py
--------------
Fixes two architectural gaps in the current p-adic transformer:

GAP 1 — No positional encoding.
    The current PadicAnomalyDetector sums digit embeddings and passes
    them to a standard TransformerEncoder with no positional information.
    This means the model is PERMUTATION INVARIANT — it cannot detect
    "ordering" attacks (tokens in wrong sequence order) at all.
    The fix: add learnable positional embeddings to HenselEmbedding.

GAP 2 — SoftPadicValuation degeneracy.
    During training, the learned `log_temperature` parameters in
    SoftPadicValuation can collapse — all temperatures converge to the
    same value and the soft valuation becomes a constant scalar.
    This means your attention weights become uniform (no structure).
    The fix: add a diagnostic probe + a temperature diversity
    regularization term that keeps the per-position temperatures spread.

Both fixes are drop-in replacements for the existing classes.
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ===========================================================================
# FIX 1: HenselEmbedding with positional encoding
# ===========================================================================

class HenselEmbeddingWithPosition(nn.Module):
    """
    Drop-in replacement for HenselEmbedding that adds positional encoding.

    Why this matters:
    The original HenselEmbedding is:
        out[b, t, :] = sum_i embed_i(digit[b, t, i])

    This is the SAME for all sequence positions t. The transformer layers
    can in principle learn position from context, but:
      (a) your sequences are short (window_size=32-48), so attention can
          span the whole sequence and never needs positional cues
      (b) ordering attacks look IDENTICAL to the original if position is
          ignored — the set of tokens is the same, only order differs

    The fix adds a standard learnable positional embedding that is ADDED
    to the Hensel embedding before the transformer sees it:
        out[b, t, :] = sum_i embed_i(digit[b, t, i]) + pos_embed[t]

    This makes the model sensitive to token order and enables detection
    of ordering/shuffle attacks.
    """

    def __init__(
        self,
        p: int,
        r: int,
        d_model: int,
        max_seq_len: int = 256,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        if p < 2:
            raise ValueError("p must be >= 2")
        if r < 1:
            raise ValueError("r must be >= 1")
        if d_model < 1:
            raise ValueError("d_model must be >= 1")

        self.p = p
        self.r = r
        self.d_model = d_model
        self.max_seq_len = max_seq_len

        # Original per-digit embeddings
        self.digit_embeds = nn.ModuleList([nn.Embedding(p, d_model) for _ in range(r)])

        # Learnable positional embeddings — one vector per sequence position
        # Alternative: use sinusoidal; learnable is better for fixed-length windows
        self.pos_embed = nn.Embedding(max_seq_len, d_model)

        self.dropout = nn.Dropout(dropout)
        self._reset_parameters()

    def _reset_parameters(self) -> None:
        for embed in self.digit_embeds:
            nn.init.normal_(embed.weight, mean=0.0, std=self.d_model ** -0.5)
        # Positional embeddings initialized small so they don't dominate early
        nn.init.normal_(self.pos_embed.weight, mean=0.0, std=0.01)

    def forward(self, digits: torch.Tensor) -> torch.Tensor:
        """
        Args:
            digits: [batch, seq, r] int64

        Returns:
            [batch, seq, d_model] float32
        """
        if digits.ndim != 3 or digits.shape[-1] != self.r:
            raise ValueError(
                f"digits must be [batch, seq, {self.r}], got {tuple(digits.shape)}"
            )
        seq_len = digits.shape[1]
        if seq_len > self.max_seq_len:
            raise ValueError(
                f"seq_len={seq_len} exceeds max_seq_len={self.max_seq_len}. "
                "Increase max_seq_len at construction."
            )

        # Hensel digit embedding (original)
        out = torch.zeros(
            digits.shape[0], digits.shape[1], self.d_model,
            dtype=torch.get_default_dtype(),
            device=digits.device,
        )
        for idx, embed in enumerate(self.digit_embeds):
            out = out + embed(digits[..., idx])

        # Add positional embedding
        positions = torch.arange(seq_len, device=digits.device)
        out = out + self.pos_embed(positions).unsqueeze(0)  # [1, seq, d_model]

        return self.dropout(out)


# ===========================================================================
# FIX 2: SoftPadicValuation with temperature diversity diagnostic
# ===========================================================================

class DiagnosedSoftPadicValuation(nn.Module):
    """
    Drop-in replacement for SoftPadicValuation that:

    1. Exposes a `temperature_stats()` method so you can check whether
       the per-position temperatures are actually differentiating.

    2. Adds a `temperature_diversity_loss()` term you can add to your
       training loss to prevent temperature collapse.

    Why temperature collapse happens:
    The original SoftPadicValuation has `log_temperature` as a learned
    parameter of shape [r]. During training, if the BCE loss dominates
    (alpha is small or the data is easy), the gradient for log_temperature
    may be tiny and all r values drift to the same local minimum.
    When that happens, every digit position gets the same weight, and
    the "soft p-adic valuation" is no longer computing shared prefix
    length — it is computing an unstructured weighted sum.

    Detection:
    Call `temperature_stats()` after each epoch. If std < 0.1 * mean,
    the temperatures have collapsed and you need to increase alpha or
    add the diversity loss.
    """

    def __init__(
        self,
        p: int,
        r: int,
        d_digit: int = 16,
        temperature: float = 4.0,
        learn_temp: bool = True,
        eps: float = 1e-6,
        diversity_weight: float = 0.01,
    ) -> None:
        super().__init__()
        if p < 2:
            raise ValueError("p must be >= 2")
        if r < 1:
            raise ValueError("r must be >= 1")
        if d_digit < 1:
            raise ValueError("d_digit must be >= 1")
        if temperature <= 0:
            raise ValueError("temperature must be > 0")

        self.p = p
        self.r = r
        self.d_digit = d_digit
        self.eps = eps
        self.diversity_weight = diversity_weight

        self.digit_embeddings = nn.ModuleList([nn.Embedding(p, d_digit) for _ in range(r)])

        if learn_temp:
            self.log_temperature = nn.Parameter(torch.full((r,), math.log(temperature)))
        else:
            self.register_buffer("log_temperature", torch.full((r,), math.log(temperature)))

        # Initialize with a gradient — low-order positions should be MORE
        # discriminative (higher temperature = sharper match signal).
        # This is the p-adic prior: position 0 matters most.
        with torch.no_grad():
            if learn_temp and isinstance(self.log_temperature, nn.Parameter):
                # Linearly decreasing temperature from position 0 to r-1
                # temp[i] = temperature * exp(-i * decay)
                decay = 0.15
                for i in range(r):
                    self.log_temperature[i] = math.log(temperature) - i * decay

        self.prefix_weights = nn.Parameter(torch.ones(r))
        self._reset_parameters()

    def _reset_parameters(self) -> None:
        for emb in self.digit_embeddings:
            nn.init.normal_(emb.weight, mean=0.0, std=self.d_digit ** -0.5)

    def temperature_stats(self) -> dict[str, float]:
        """
        Call this after each training epoch to monitor temperature health.

        Healthy output: temperatures should decrease from position 0 to r-1
        (low-order digits are more discriminative in p-adic metric).

        Collapse signal: std < 0.1 * mean — all positions have converged
        to the same temperature and the valuation has lost structure.
        """
        temps = self.log_temperature.exp().detach()
        return {
            "temp_mean": float(temps.mean().item()),
            "temp_std": float(temps.std().item()),
            "temp_min": float(temps.min().item()),
            "temp_max": float(temps.max().item()),
            "temp_pos0": float(temps[0].item()),
            "temp_pos_last": float(temps[-1].item()),
            "collapsed": bool((temps.std() < 0.1 * temps.mean()).item()),
        }

    def temperature_diversity_loss(self) -> torch.Tensor:
        """
        Regularization term that penalizes temperature collapse.

        Encourages the learned temperatures to spread across the r positions
        rather than converging to a single value.

        Add to your total loss:
            total_loss += valuation.temperature_diversity_loss()
        """
        temps = self.log_temperature.exp()
        # Penalize low variance relative to mean (coefficient of variation)
        mean = temps.mean()
        std = temps.std()
        cv = std / (mean + self.eps)
        # We want cv to be large; penalize if cv < 0.3
        target_cv = 0.3
        return self.diversity_weight * F.relu(target_cv - cv)

    def _soft_match_at_position(
        self,
        digits_a: torch.Tensor,
        digits_b: torch.Tensor,
        position: int,
    ) -> torch.Tensor:
        emb = self.digit_embeddings[position]
        ea = emb(digits_a)
        eb = emb(digits_b)
        sq_dist = ((ea - eb) ** 2).sum(dim=-1)
        tau = self.log_temperature[position].exp().clamp(min=0.01, max=50.0)
        return torch.exp(-tau * sq_dist)

    def forward(self, digits_a: torch.Tensor, digits_b: torch.Tensor) -> torch.Tensor:
        if digits_a.shape != digits_b.shape:
            raise ValueError("digits_a and digits_b must have the same shape")
        if digits_a.shape[-1] != self.r:
            raise ValueError(f"Last dimension must be r={self.r}")

        log_matches = []
        for pos in range(self.r):
            match = self._soft_match_at_position(
                digits_a[..., pos], digits_b[..., pos], pos
            )
            log_matches.append(torch.log(match.clamp_min(self.eps)))

        log_match_tensor = torch.stack(log_matches, dim=-1)
        log_prefix = torch.cumsum(log_match_tensor, dim=-1)
        prefix = torch.exp(log_prefix)
        weights = F.softplus(self.prefix_weights)
        soft_val = (prefix * weights).sum(dim=-1)
        return soft_val / (weights.sum() + self.eps)


# ===========================================================================
# FIX 3: Updated training loop hook for temperature monitoring
# ===========================================================================

def collect_valuation_modules(model: nn.Module) -> list[DiagnosedSoftPadicValuation]:
    """Find all DiagnosedSoftPadicValuation modules in a model."""
    return [
        m for m in model.modules()
        if isinstance(m, DiagnosedSoftPadicValuation)
    ]


def log_temperature_health(model: nn.Module, epoch: int) -> None:
    """
    Call at the end of each training epoch.

    Prints a warning if any valuation module has collapsed temperatures.
    If you see 'COLLAPSED' warnings, increase alpha (contrastive weight)
    or add temperature_diversity_loss() to your training objective.

    Example usage in train():
        for epoch in range(1, config.epochs + 1):
            train_metrics = _train_epoch(...)
            log_temperature_health(model, epoch)   # <-- add this line
    """
    modules = collect_valuation_modules(model)
    if not modules:
        return

    for i, m in enumerate(modules):
        stats = m.temperature_stats()
        status = "COLLAPSED ⚠️" if stats["collapsed"] else "ok"
        print(
            f"  Epoch {epoch} | valuation[{i}] temperatures: "
            f"mean={stats['temp_mean']:.3f} std={stats['temp_std']:.3f} "
            f"pos0={stats['temp_pos0']:.3f} posN={stats['temp_pos_last']:.3f} "
            f"[{status}]"
        )
        if stats["collapsed"]:
            print(
                "    -> Temperatures have collapsed. "
                "Increase alpha or add temperature_diversity_loss() to training."
            )


def compute_diversity_regularization(model: nn.Module) -> torch.Tensor:
    """
    Aggregate temperature diversity loss across all valuation modules.

    Add the return value to your total loss in _train_epoch:
        loss = main_loss + compute_diversity_regularization(model)
    """
    modules = collect_valuation_modules(model)
    if not modules:
        # Return a no-op zero tensor; device doesn't matter since it's 0
        return torch.tensor(0.0)
    return sum(m.temperature_diversity_loss() for m in modules)
