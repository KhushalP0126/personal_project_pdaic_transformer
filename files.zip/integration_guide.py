# INTEGRATION GUIDE
# How to apply the three fixes to your existing codebase.
# Each section shows the exact change, why it matters, and what to expect.

# ===========================================================================
# CHANGE 1 — Replace SyscallAnomalyDataset with RealisticBusDataset
# File: scripts/train_anomaly_detector.py and src/padic_transformer/training.py
# ===========================================================================

# In training.py, find the build_dataloaders call inside train():
# BEFORE (line ~240 in training.py):
#
#   from .dataset import AnomalyDatasetConfig, build_dataloaders
#   anomaly_cfg = AnomalyDatasetConfig(
#       window_size=config.window_size,
#       attack_fraction=config.attack_fraction,   # DEFAULT IS 0.3 — TOO HIGH
#       ...
#   )
#   train_loader, val_loader = build_dataloaders(...)

# AFTER:
#
#   from dataset_realistic import RealisticBusDataset, RealisticDatasetConfig, make_weighted_loss
#   from padic_transformer.ultrametric import generate_clustered_hensel_dataset
#   from torch.utils.data import DataLoader
#
#   realistic_cfg = RealisticDatasetConfig(
#       window_size=config.window_size,
#       attack_fraction=0.005,          # 0.5% — realistic for hardware
#       idle_fraction=0.70,             # 70% idle cycles
#       attack_kinds=("cross_class", "stuck_at", "burst", "ordering"),
#       attack_min_len=config.attack_min_len,
#       attack_max_len=config.attack_max_len,
#       seed=config.seed,
#   )
#   train_hensel = generate_clustered_hensel_dataset(benchmark_cfg, device="cpu")
#   val_hensel   = generate_clustered_hensel_dataset(val_cfg, device="cpu")
#   train_ds = RealisticBusDataset(train_hensel, realistic_cfg, n_samples=config.n_train)
#   val_ds   = RealisticBusDataset(val_hensel, realistic_cfg, n_samples=config.n_val)
#
#   # CRITICAL: use frequency-weighted loss
#   loss_fn = make_weighted_loss(train_ds, p=config.p, alpha=config.alpha)
#
#   pin = device.type == "cuda"
#   train_loader = DataLoader(train_ds, batch_size=config.batch_size, shuffle=True,
#                             num_workers=config.num_workers, pin_memory=pin, drop_last=True)
#   val_loader   = DataLoader(val_ds, batch_size=config.batch_size * 2, shuffle=False,
#                             num_workers=config.num_workers, pin_memory=pin)

# Expected result after this change:
# - AUROC will likely DROP from 0.77 to 0.55-0.65 initially.
#   This is NOT a regression — you were measuring an easy problem.
#   The new number is honest. Work from there.
# - pos_weight will print something like "pos_weight=199.0"
#   (199 normal samples per attack sample at 0.5% rate).
#   This is correct and necessary.


# ===========================================================================
# CHANGE 2 — Add positional encoding to the embedding
# File: src/padic_transformer/model.py
# ===========================================================================

# Option A: Replace HenselEmbedding in PadicAnomalyDetector
# In model.py, change the __init__ of PadicAnomalyDetector:
#
# BEFORE:
#   from .model import HenselEmbedding
#   self.embedding = HenselEmbedding(p=p, r=r, d_model=d_model)
#
# AFTER:
#   import sys; sys.path.insert(0, '.')
#   from model_fixes import HenselEmbeddingWithPosition
#   self.embedding = HenselEmbeddingWithPosition(
#       p=p, r=r, d_model=d_model,
#       max_seq_len=256,     # set to your max window_size
#       dropout=dropout,
#   )

# Option B: Add to PadicAttentionAnomalyDetector (padic_attention.py)
# Same change — replace HenselEmbedding with HenselEmbeddingWithPosition.

# Expected result after this change:
# - The model can now detect ORDERING attacks (token shuffle).
# - You will see a small increase in parameter count (~256*d_model extra params).
# - Training may need 1-2 extra warmup epochs while positional embeddings learn.
# - Most importantly: run the ordering-attack-only subset to verify detection works.


# ===========================================================================
# CHANGE 3 — Add temperature monitoring and diversity loss
# File: src/padic_transformer/training.py  (inside train() function)
# ===========================================================================

# Step 3a: Import the diagnostic tools at the top of training.py
#   from model_fixes import log_temperature_health, compute_diversity_regularization

# Step 3b: In _train_epoch(), add diversity loss to the total:
#
# BEFORE (around line 285 in training.py):
#   loss, bce_loss, ctr_loss = loss_fn(logits, labels, representations)
#   loss = loss / grad_accum
#
# AFTER:
#   loss, bce_loss, ctr_loss = loss_fn(logits, labels, representations)
#   diversity_loss = compute_diversity_regularization(model)
#   loss = (loss + diversity_loss) / grad_accum

# Step 3c: In train(), after each epoch's val_metrics call, add:
#
# BEFORE (around line 340):
#   print(f"Epoch {epoch:>3}/{config.epochs} ...")
#
# AFTER:
#   print(f"Epoch {epoch:>3}/{config.epochs} ...")
#   log_temperature_health(model, epoch)   # <-- add this line

# Expected result after this change:
# - Each epoch prints temperature stats. Watch for "COLLAPSED" warnings.
# - If temperatures are healthy, temp_pos0 > temp_pos_last (position 0 is sharper).
# - If you see collapse warnings, increase alpha from 0.5 to 1.0 or 2.0.


# ===========================================================================
# CHANGE 4 — Run baselines before your next GPU run
# ===========================================================================

# Add this to a new script, e.g. scripts/run_baselines.py:
#
#   from baselines_and_validation import (
#       run_isolation_forest_baseline,
#       run_standard_transformer_baseline,
#   )
#   from dataset_realistic import RealisticBusDataset, RealisticDatasetConfig
#   from padic_transformer.ultrametric import generate_clustered_hensel_dataset
#   from padic_transformer.config import BenchmarkConfig
#
#   benchmark_cfg = BenchmarkConfig(p=3, r=8, samples=4096, classes=16,
#                                    tokens_per_class=256, seed=20260504)
#   realistic_cfg = RealisticDatasetConfig(attack_fraction=0.005, idle_fraction=0.70)
#
#   hensel = generate_clustered_hensel_dataset(benchmark_cfg)
#   ds_train = RealisticBusDataset(hensel, realistic_cfg, n_samples=8192)
#   ds_val   = RealisticBusDataset(hensel, realistic_cfg, n_samples=2048)
#
#   # Baseline 1: Isolation Forest
#   iso_results = run_isolation_forest_baseline(
#       ds_train.windows, ds_train.labels,
#       ds_val.windows,   ds_val.labels,
#   )
#
#   # Baseline 2: Standard Transformer
#   std_results = run_standard_transformer_baseline(
#       ds_train.windows, ds_train.labels,
#       ds_val.windows,   ds_val.labels,
#       p=3, d_model=256, n_layers=4, epochs=10,
#       pos_weight=ds_train.pos_weight,
#   )
#
#   print(f"\nSummary:")
#   print(f"  IsolationForest AUROC : {iso_results.get('auroc', 'N/A'):.4f}")
#   print(f"  StandardTransformer   : {std_results.get('auroc', 'N/A'):.4f}")
#   print(f"  Your p-adic model     : ??? (run train.py to get this)")


# ===========================================================================
# CHANGE 5 — Validate on ADFA-LD (when ready)
# ===========================================================================

# Once you have downloaded ADFA-LD:
#   from baselines_and_validation import load_adfa_ld
#   windows, labels = load_adfa_ld(
#       data_dir="/path/to/ADFA-LD",
#       p=3, r=8,
#       window_size=32,
#       stride=1,
#   )
#   # Then pass windows/labels to your existing train/val split logic.
#
# Key things to check on real data:
# 1. Does ultrametric_violation_rate stay near 0? If not, the p-adic assumption fails.
# 2. What is the real attack rate? If it's 0.001% not 0.5%, re-tune pos_weight.
# 3. Do all four attack_kinds generalize? Test each archetype separately on ADFA-LD.


# ===========================================================================
# EXPECTED TIMELINE
# ===========================================================================
#
# Day 1-2:  Apply Change 1 (realistic dataset). Re-run train-cpu. Record new AUROC.
# Day 3:    Apply Change 2 (positional encoding). Compare AUROC on ordering attacks.
# Day 4:    Apply Change 3 (temperature monitoring). Check for collapse in logs.
# Day 5:    Apply Change 4 (baselines). You now have 3 comparable AUROC numbers.
# Week 2:   Download ADFA-LD. Run load_adfa_ld. Validate ultrametric assumption.
# Week 3+:  If real-data AUROC > baseline on ADFA-LD, you have a publishable result.
