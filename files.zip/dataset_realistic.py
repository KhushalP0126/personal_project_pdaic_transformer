"""
dataset_realistic.py
--------------------
Drop-in replacement for SyscallAnomalyDataset that fixes three bugs
in the original synthetic generator:

BUG 1 — attack_fraction is too high (default 0.3 = 30%).
    Real hardware bus traces have anomaly rates of 0.1-1%.
    The original setting trains the model on an unrealistically easy
    balanced problem. AUROC of 0.77 is inflated because at 30% attack
    rate a trivial threshold works.

BUG 2 — no idle cycles.
    Real bus traces are dominated by idle/NOP cycles (often 70-95%).
    Without them the model never learns what "normal steady-state" looks
    like; it only learns class-cluster transitions.

BUG 3 — all attack segments are cross-class substitutions.
    This is only one attack archetype. Real attacks include:
      - Repeated access to the same address (stuck-at patterns)
      - Unusual *ordering* of otherwise normal tokens
      - Burst access patterns (DMA-style)
    The original generator cannot produce any of these.

This file replaces SyscallAnomalyDataset with RealisticBusDataset and
adds three attack factories covering the archetypes above. It also adds
a ClassFrequencyWeightedLoss wrapper that re-weights BCE to handle the
extreme class imbalance.

Usage (drop-in):
    from dataset_realistic import RealisticBusDataset, make_weighted_loss
    ds = RealisticBusDataset(hensel_data, cfg, n_samples=n_train)
    loss_fn = make_weighted_loss(ds, p=config.p, alpha=config.alpha)
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Literal

import torch
from torch.utils.data import DataLoader, Dataset

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

AttackKind = Literal["cross_class", "stuck_at", "burst", "ordering"]


@dataclass(frozen=True)
class RealisticDatasetConfig:
    """
    Configuration for realistic bus-trace simulation.

    Key parameters vs. the original AnomalyDatasetConfig:

    attack_fraction:  keep at or below 0.01 (1%) for hardware realism.
                      0.3 (the original default) is ~100× too high.

    idle_fraction:    fraction of the token stream to replace with a
                      single "idle" token before windowing.
                      0.7 means 70% of bus cycles are idle NOPs —
                      a conservative estimate for a real embedded bus.

    attack_kinds:     list of attack archetypes to sample from uniformly.
                      "cross_class"  — original substitution attack
                      "stuck_at"     — segment replaced by one repeated token
                      "burst"        — segment from a high-frequency class
                      "ordering"     — tokens shuffled within the attack segment
    """

    window_size: int = 32
    attack_fraction: float = 0.005          # 0.5% — realistic for hardware
    idle_fraction: float = 0.70             # 70% idle cycles
    attack_min_len: int = 2
    attack_max_len: int = 8
    attack_kinds: tuple[AttackKind, ...] = ("cross_class", "stuck_at", "burst", "ordering")
    seed: int = 20260504

    def validate(self) -> None:
        if not 2 <= self.window_size <= 4096:
            raise ValueError(f"window_size must be in [2, 4096], got {self.window_size}")
        if not 0.0 < self.attack_fraction < 0.5:
            raise ValueError(
                f"attack_fraction={self.attack_fraction} looks wrong. "
                "For hardware realism keep below 0.05. "
                "If you intentionally want a high rate, set allow_high_rate=True."
            )
        if not 0.0 <= self.idle_fraction < 1.0:
            raise ValueError(f"idle_fraction must be in [0, 1), got {self.idle_fraction}")
        if self.attack_min_len < 1:
            raise ValueError(f"attack_min_len must be >= 1, got {self.attack_min_len}")
        eff_max = min(self.attack_max_len, self.window_size)
        if self.attack_min_len > eff_max:
            raise ValueError(
                f"attack_min_len ({self.attack_min_len}) > "
                f"effective attack_max_len ({eff_max})"
            )
        if not self.attack_kinds:
            raise ValueError("attack_kinds must be non-empty")


# ---------------------------------------------------------------------------
# Idle token injection
# ---------------------------------------------------------------------------

def inject_idle_cycles(
    token_digits: torch.Tensor,
    token_labels: torch.Tensor,
    idle_fraction: float,
    p: int,
    r: int,
    rng: torch.Generator,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Replace `idle_fraction` of tokens with a fixed "idle" token.

    The idle token is all-zeros in Hensel space (the additive identity,
    which is a sensible encoding for a NOP/idle bus cycle).

    Returns new (token_digits, token_labels) with an extra class label
    of -1 for idle tokens so downstream code can identify them.

    NOTE: idle tokens are assigned label -1. The ultrametric structure
    of the non-idle tokens is preserved exactly.
    """
    n = token_digits.shape[0]
    n_idle = int(n * idle_fraction)

    # Choose idle positions uniformly without replacement
    perm = torch.randperm(n, generator=rng)
    idle_positions = perm[:n_idle]

    new_digits = token_digits.clone()
    new_labels = token_labels.clone()

    # Idle token: all zeros (p-adic additive identity)
    idle_token = torch.zeros(r, dtype=torch.int64, device=token_digits.device)
    new_digits[idle_positions] = idle_token
    new_labels[idle_positions] = -1   # sentinel for idle

    return new_digits, new_labels


# ---------------------------------------------------------------------------
# Attack factories
# ---------------------------------------------------------------------------

def _attack_cross_class(
    base: torch.Tensor,
    inject_pos: int,
    attack_len: int,
    token_digits: torch.Tensor,
    token_labels: torch.Tensor,
    majority_label: int,
    rng: torch.Generator,
) -> torch.Tensor:
    """Original attack: replace segment with tokens from another class."""
    candidate_idx = (token_labels != majority_label).nonzero(as_tuple=True)[0]
    if candidate_idx.numel() == 0:
        warnings.warn(
            "cross_class attack: no cross-class tokens found. "
            "Returning unmodified window.",
            RuntimeWarning,
            stacklevel=3,
        )
        return base
    sample_ids = torch.randint(0, candidate_idx.numel(), (attack_len,), generator=rng)
    chosen = candidate_idx[sample_ids]
    base[inject_pos: inject_pos + attack_len] = token_digits[chosen].clone()
    return base


def _attack_stuck_at(
    base: torch.Tensor,
    inject_pos: int,
    attack_len: int,
    token_digits: torch.Tensor,
    rng: torch.Generator,
) -> torch.Tensor:
    """
    Stuck-at attack: one token repeated for the entire attack segment.

    Models a bus line stuck at a fixed value — common in hardware fault
    injection and certain cache side-channel patterns.
    """
    pick = int(torch.randint(0, token_digits.shape[0], (1,), generator=rng).item())
    stuck_token = token_digits[pick].clone()
    base[inject_pos: inject_pos + attack_len] = stuck_token.unsqueeze(0).expand(attack_len, -1)
    return base


def _attack_burst(
    base: torch.Tensor,
    inject_pos: int,
    attack_len: int,
    token_digits: torch.Tensor,
    token_labels: torch.Tensor,
    rng: torch.Generator,
) -> torch.Tensor:
    """
    Burst attack: the same class token repeated at high frequency.

    Models DMA-style repeated memory access or instruction fetch bursts
    that are individually normal but anomalous in density.
    """
    # Pick any class and repeat tokens from it — the repetition is the anomaly
    n_classes = int(token_labels.max().item()) + 1
    target_class = int(torch.randint(0, n_classes, (1,), generator=rng).item())
    candidate_idx = (token_labels == target_class).nonzero(as_tuple=True)[0]
    if candidate_idx.numel() == 0:
        return base
    sample_ids = torch.randint(0, candidate_idx.numel(), (attack_len,), generator=rng)
    chosen = candidate_idx[sample_ids]
    base[inject_pos: inject_pos + attack_len] = token_digits[chosen].clone()
    return base


def _attack_ordering(
    base: torch.Tensor,
    inject_pos: int,
    attack_len: int,
    rng: torch.Generator,
) -> torch.Tensor:
    """
    Ordering attack: shuffle the tokens within the attack segment.

    The individual tokens are all normal; only their order is wrong.
    This is the hardest attack type for token-identity-based models
    and the most important one to include — it tests whether the
    transformer is using sequential structure at all.

    If your model cannot detect this attack, it means your attention
    is not using positional/sequential information and you need to
    add positional encodings.
    """
    segment = base[inject_pos: inject_pos + attack_len].clone()
    perm = torch.randperm(attack_len, generator=rng)
    base[inject_pos: inject_pos + attack_len] = segment[perm]
    return base


# ---------------------------------------------------------------------------
# Main dataset
# ---------------------------------------------------------------------------

class RealisticBusDataset(Dataset):
    """
    Realistic bus-trace anomaly dataset.

    Replaces SyscallAnomalyDataset with:
      - Configurable idle-cycle injection (default 70%)
      - Low attack_fraction (default 0.5%)
      - Four attack archetypes instead of one
      - Hard warning if attack_fraction > 5%

    The dataset reports per-attack-kind statistics via
    `self.attack_kind_counts` for debugging.
    """

    def __init__(
        self,
        hensel_data: object,      # HenselDataset from ultrametric.py
        cfg: RealisticDatasetConfig,
        n_samples: int,
    ) -> None:
        cfg.validate()

        if cfg.attack_fraction > 0.05:
            warnings.warn(
                f"attack_fraction={cfg.attack_fraction:.3f} is above 5%. "
                "For hardware bus anomaly detection this is unrealistically high "
                "and will inflate AUROC. Consider 0.001-0.01.",
                UserWarning,
                stacklevel=2,
            )

        self.hensel_data = hensel_data
        self.cfg = cfg
        self.n_samples = n_samples

        rng = torch.Generator()
        rng.manual_seed(cfg.seed)

        p = int(hensel_data.token_digits.max().item()) + 1
        r = hensel_data.token_digits.shape[1]

        # --- inject idle cycles into the token stream ---
        token_digits, token_labels = inject_idle_cycles(
            hensel_data.token_digits,
            hensel_data.token_labels,
            cfg.idle_fraction,
            p=p,
            r=r,
            rng=rng,
        )

        n_tokens = token_digits.shape[0]
        window = cfg.window_size
        if n_tokens < window:
            raise ValueError(
                f"window_size ({window}) > token stream length ({n_tokens}) "
                "after idle injection. Increase samples or reduce idle_fraction."
            )

        n_attack = max(1, int(n_samples * cfg.attack_fraction))
        n_normal = n_samples - n_attack

        if n_normal < 1:
            raise ValueError(
                "n_samples too small for the given attack_fraction. "
                "Increase n_samples."
            )

        # --- normal windows ---
        normal_starts = torch.randint(0, n_tokens - window + 1, (n_normal,), generator=rng)
        normal_windows = torch.stack([
            token_digits[s: s + window].clone() for s in normal_starts
        ])

        # --- attack windows ---
        attack_starts = torch.randint(0, n_tokens - window + 1, (n_attack,), generator=rng)
        attack_windows = []
        self.attack_kind_counts: dict[str, int] = {k: 0 for k in cfg.attack_kinds}

        for start in attack_starts:
            win, kind = self._inject_attack(
                int(start.item()), window, token_digits, token_labels, p, rng
            )
            attack_windows.append(win)
            self.attack_kind_counts[kind] += 1

        all_windows = torch.cat([normal_windows, torch.stack(attack_windows)], dim=0)
        all_labels = torch.cat([
            torch.zeros(n_normal, dtype=torch.float32),
            torch.ones(n_attack, dtype=torch.float32),
        ])
        perm = torch.randperm(n_samples, generator=rng)
        self.windows = all_windows[perm]
        self.labels = all_labels[perm]

        n_pos = int(self.labels.sum().item())
        n_neg = n_samples - n_pos
        # Store pos_weight for use in loss function
        self.pos_weight: float = n_neg / max(1, n_pos)

        print(
            f"RealisticBusDataset: {n_samples} samples | "
            f"normal={n_normal} attack={n_attack} "
            f"(pos_weight={self.pos_weight:.1f}) | "
            f"idle_fraction={cfg.idle_fraction:.2f} | "
            f"attack_kinds={self.attack_kind_counts}"
        )

    def _inject_attack(
        self,
        start: int,
        window: int,
        token_digits: torch.Tensor,
        token_labels: torch.Tensor,
        p: int,
        rng: torch.Generator,
    ) -> tuple[torch.Tensor, AttackKind]:
        base = token_digits[start: start + window].clone()

        eff_max = min(self.cfg.attack_max_len, window)
        attack_len = int(
            torch.randint(self.cfg.attack_min_len, eff_max + 1, (1,), generator=rng).item()
        )
        inject_pos = int(
            torch.randint(0, window - attack_len + 1, (1,), generator=rng).item()
        )

        # Choose attack kind uniformly
        kind_idx = int(
            torch.randint(0, len(self.cfg.attack_kinds), (1,), generator=rng).item()
        )
        kind: AttackKind = self.cfg.attack_kinds[kind_idx]

        region = torch.arange(start + inject_pos, start + inject_pos + attack_len)
        window_labels = token_labels[region]
        valid_mask = window_labels >= 0  # exclude idle tokens
        if valid_mask.sum() == 0:
            majority_label = 0
        else:
            majority_label = int(window_labels[valid_mask].mode().values.item())

        if kind == "cross_class":
            base = _attack_cross_class(
                base, inject_pos, attack_len, token_digits, token_labels,
                majority_label, rng
            )
        elif kind == "stuck_at":
            base = _attack_stuck_at(base, inject_pos, attack_len, token_digits, rng)
        elif kind == "burst":
            base = _attack_burst(
                base, inject_pos, attack_len, token_digits, token_labels, rng
            )
        elif kind == "ordering":
            base = _attack_ordering(base, inject_pos, attack_len, rng)

        return base, kind

    def __len__(self) -> int:
        return self.n_samples

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.windows[idx], self.labels[idx]


# ---------------------------------------------------------------------------
# Weighted loss factory
# ---------------------------------------------------------------------------

def make_weighted_loss(
    dataset: RealisticBusDataset,
    p: int,
    alpha: float = 0.5,
    margin_pos: float = 0.1,
    margin_neg: float = 0.5,
    max_pairs: int = 4096,
) -> "AnomalyLoss":
    """
    Build an AnomalyLoss with pos_weight derived from dataset class frequencies.

    This is critical for imbalanced data. Without it, BCE loss on 0.5%
    anomaly rate will converge to predicting all-normal and report 99.5%
    accuracy while detecting nothing.

    The pos_weight balances the gradient contribution of the rare positive
    class so the model actually learns the anomaly boundary.
    """
    # Import here to avoid circular dependency when used standalone
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    from padic_transformer.losses import AnomalyLoss

    print(f"make_weighted_loss: pos_weight={dataset.pos_weight:.2f} "
          f"(n_neg/n_pos — balances class imbalance)")

    return AnomalyLoss(
        p=p,
        alpha=alpha,
        pos_weight=dataset.pos_weight,   # KEY: derived from actual frequencies
        margin_pos=margin_pos,
        margin_neg=margin_neg,
        max_pairs=max_pairs,
    )
