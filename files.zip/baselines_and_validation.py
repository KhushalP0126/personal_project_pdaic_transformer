"""
baselines_and_validation.py
---------------------------
Two things in one file:

PART A — Baseline comparisons (isolation forest, standard transformer).
    Run these BEFORE claiming the p-adic model is better.
    Your current codebase has no baselines. A reviewer will ask for them
    immediately. These run on the same data and report the same metrics.

PART B — Real dataset guide and download helpers.
    Answers the question: "what dataset should I use to validate hardware results?"

    The short answer for hardware bus anomaly detection:
    
    BEST FIT:  ADFA-LD (Linux syscall traces, labeled attacks)
               https://research.unsw.edu.au/projects/adfa-ids-datasets
    
    ALSO GOOD: KDD Cup 1999 (network, but well-understood baseline)
               BETH Dataset (Linux audit logs, 2021, modern)
               MIMII Dataset (machine sound, if your bus is industrial)
    
    See DATASET_GUIDE dict at the bottom of this file for details.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# Add src to path
SRC_ROOT = Path(__file__).resolve().parents[1] / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))


# ===========================================================================
# PART A: Baselines
# ===========================================================================

# ---------------------------------------------------------------------------
# Baseline 1: Isolation Forest on flattened Hensel digits
# ---------------------------------------------------------------------------

def run_isolation_forest_baseline(
    train_windows: torch.Tensor,   # [N, seq, r]
    train_labels: torch.Tensor,    # [N] float32, 0/1
    val_windows: torch.Tensor,
    val_labels: torch.Tensor,
) -> dict[str, float]:
    """
    Flatten each window to [seq*r] and run sklearn IsolationForest.

    This is the minimum viable baseline. If your p-adic transformer
    cannot beat this, the transformer architecture is not adding value.

    IsolationForest is unsupervised (only trains on normal data), which
    is appropriate for anomaly detection — you often don't have labeled
    attack data in production.
    """
    try:
        from sklearn.ensemble import IsolationForest
        from sklearn.metrics import roc_auc_score, f1_score
        import numpy as np
    except ImportError:
        print("sklearn not installed. Run: pip install scikit-learn")
        return {}

    # Flatten: [N, seq*r]
    X_train = train_windows.reshape(train_windows.shape[0], -1).numpy().astype(np.float32)
    X_val   = val_windows.reshape(val_windows.shape[0], -1).numpy().astype(np.float32)
    y_val   = val_labels.numpy().astype(int)

    # Train ONLY on normal samples (unsupervised, as in production)
    normal_mask = train_labels.numpy() == 0
    X_train_normal = X_train[normal_mask]

    t0 = time.perf_counter()
    clf = IsolationForest(n_estimators=100, contamination=0.01, random_state=42, n_jobs=-1)
    clf.fit(X_train_normal)
    train_time = time.perf_counter() - t0

    # IsolationForest returns -1 (anomaly) / +1 (normal)
    # scores: more negative = more anomalous
    scores = -clf.score_samples(X_val)   # flip so higher = more anomalous
    preds  = (clf.predict(X_val) == -1).astype(int)

    auroc = float(roc_auc_score(y_val, scores)) if len(set(y_val)) > 1 else 0.5
    f1    = float(f1_score(y_val, preds, zero_division=0))

    print(f"IsolationForest baseline: AUROC={auroc:.4f}  F1={f1:.4f}  "
          f"train_time={train_time:.2f}s  "
          f"(trained on {X_train_normal.shape[0]} normal samples)")
    return {"auroc": auroc, "f1": f1, "train_time_s": train_time}


# ---------------------------------------------------------------------------
# Baseline 2: Standard Transformer (same size, no p-adic structure)
# ---------------------------------------------------------------------------

class StandardTransformerDetector(nn.Module):
    """
    A standard transformer anomaly detector with:
    - Learnable token embeddings (not p-adic Hensel, just lookup by int ID)
    - Standard sinusoidal or learnable positional encoding
    - Same architecture dimensions as PadicAnomalyDetector

    This is your most important baseline. If this matches or beats your
    p-adic model on the same data, the ultrametric structure is not
    contributing and you need to redesign the experiment.

    The key architectural difference from PadicAnomalyDetector:
    - This model treats each window position as an integer token ID
      and looks it up in a flat embedding table.
    - It has NO inductive bias toward hierarchical/tree structure.
    - It has positional encoding built in.

    If your bus trace data is genuinely hierarchical (ultrametric),
    the p-adic model should outperform this on distribution shift,
    even if they match on in-distribution test accuracy.
    """

    def __init__(
        self,
        vocab_size: int,       # number of distinct integer token IDs
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 4,
        ffn_dim: int = 1024,
        head_hidden: int = 128,
        dropout: float = 0.1,
        max_seq_len: int = 256,
    ) -> None:
        super().__init__()
        self.d_model = d_model

        # Flat token embedding (no Hensel structure)
        self.token_embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed   = nn.Embedding(max_seq_len, d_model)
        self.embed_drop  = nn.Dropout(dropout)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=ffn_dim,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=n_layers,
            enable_nested_tensor=False,
        )
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, head_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(head_hidden, 1),
        )

    @staticmethod
    def digits_to_ids(windows: torch.Tensor, p: int) -> torch.Tensor:
        """
        Convert [batch, seq, r] Hensel digits to [batch, seq] integer IDs.
        Maps each digit vector to a single integer by treating it as a
        base-p number. This is the inverse of int64_to_digits.
        """
        r = windows.shape[-1]
        powers = torch.tensor([p ** i for i in range(r)], dtype=torch.int64, device=windows.device)
        return (windows * powers).sum(dim=-1)   # [batch, seq]

    def forward_with_features(
        self,
        token_ids: torch.Tensor,           # [batch, seq] int64
        padding_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        seq_len = token_ids.shape[1]
        positions = torch.arange(seq_len, device=token_ids.device)
        x = self.token_embed(token_ids) + self.pos_embed(positions).unsqueeze(0)
        x = self.embed_drop(x)
        h = self.encoder(x, src_key_padding_mask=padding_mask)
        pooled = h.mean(dim=1)
        logits = self.head(pooled).squeeze(-1)
        return logits, pooled

    def forward(self, token_ids: torch.Tensor, padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        logits, _ = self.forward_with_features(token_ids, padding_mask)
        return logits

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def run_standard_transformer_baseline(
    train_windows: torch.Tensor,   # [N, seq, r] Hensel digits
    train_labels: torch.Tensor,
    val_windows: torch.Tensor,
    val_labels: torch.Tensor,
    p: int,
    d_model: int = 256,
    n_heads: int = 8,
    n_layers: int = 4,
    epochs: int = 10,
    batch_size: int = 256,
    lr: float = 3e-4,
    pos_weight: float = 1.0,
    device: torch.device | None = None,
) -> dict[str, float]:
    """
    Train a standard transformer baseline and return AUROC/F1.

    Use the same hyperparameters as your p-adic model for a fair comparison.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Compute vocab size: p^r possible token values
    r = train_windows.shape[-1]
    vocab_size = p ** r
    print(f"StandardTransformer: vocab_size={vocab_size}  d_model={d_model}  "
          f"n_layers={n_layers}")

    model = StandardTransformerDetector(
        vocab_size=vocab_size,
        d_model=d_model,
        n_heads=n_heads,
        n_layers=n_layers,
        ffn_dim=d_model * 4,
        head_hidden=d_model // 2,
    ).to(device)
    print(f"  Parameters: {model.count_parameters():,}")

    # Convert Hensel digits to integer IDs
    train_ids = StandardTransformerDetector.digits_to_ids(train_windows, p)
    val_ids   = StandardTransformerDetector.digits_to_ids(val_windows, p)

    train_ds = TensorDataset(train_ids, train_labels)
    val_ds   = TensorDataset(val_ids, val_labels)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader   = DataLoader(val_ds, batch_size=batch_size * 2, shuffle=False)

    pw = torch.tensor([pos_weight], device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pw)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-2)

    best_auroc = 0.0
    t0 = time.perf_counter()

    for epoch in range(1, epochs + 1):
        model.train()
        for ids_batch, labels_batch in train_loader:
            ids_batch    = ids_batch.to(device)
            labels_batch = labels_batch.to(device)
            logits, _ = model.forward_with_features(ids_batch)
            loss = criterion(logits, labels_batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # Validation
        model.eval()
        all_logits, all_labels = [], []
        with torch.no_grad():
            for ids_batch, labels_batch in val_loader:
                logits, _ = model.forward_with_features(ids_batch.to(device))
                all_logits.append(logits.cpu())
                all_labels.append(labels_batch.cpu())

        logits_cat = torch.cat(all_logits)
        labels_cat = torch.cat(all_labels).long()

        try:
            from sklearn.metrics import roc_auc_score
            auroc = float(roc_auc_score(labels_cat.numpy(), logits_cat.numpy()))
        except Exception:
            auroc = 0.5

        if auroc > best_auroc:
            best_auroc = auroc
        print(f"  Epoch {epoch}/{epochs}  AUROC={auroc:.4f}  best={best_auroc:.4f}")

    elapsed = time.perf_counter() - t0
    print(f"StandardTransformer: best_AUROC={best_auroc:.4f}  time={elapsed:.1f}s")
    return {"auroc": best_auroc, "train_time_s": elapsed}


# ===========================================================================
# PART B: Dataset guide for hardware bus validation
# ===========================================================================

DATASET_GUIDE: dict[str, dict[str, str]] = {
    "ADFA-LD": {
        "what": (
            "Linux syscall traces from real attack scenarios. "
            "Programs are instrumented with strace; each trace is a sequence "
            "of syscall IDs — structurally identical to your synthetic Hensel sequences."
        ),
        "why": (
            "Best direct match for your project. Syscall IDs map naturally to "
            "Hensel digits. The ADFA attack set includes webshell, hydra brute-force, "
            "adduser, java exploit — all produce abnormal syscall sequences."
        ),
        "how_to_map": (
            "Map each syscall ID to a Hensel digit vector using your DEFAULT_SYSCALL_MAP "
            "pattern from int8_2adic.py. Use p=2 or p=3; assign IDs to 2-adic residues "
            "such that behaviorally related syscalls share low-order bits."
        ),
        "url": "https://research.unsw.edu.au/projects/adfa-ids-datasets",
        "format": "Text files, one syscall ID per line, one file per process trace",
        "size": "~130MB, ~800 normal traces + attack traces for 6 attack families",
        "caveat": (
            "Labels are at trace level (whole trace is attack or normal), "
            "not at the individual syscall level. You will need to assume the "
            "attack is present somewhere in the trace and use weak supervision."
        ),
    },

    "BETH": {
        "what": (
            "Large-scale Linux audit log dataset collected from real honeypots. "
            "Contains process creation, file access, and network events. "
            "Published 2021 by NCSA/UIUC, specifically designed for ML-based IDS."
        ),
        "why": (
            "More modern and larger than ADFA-LD. Has richer event types. "
            "The event ID sequences are directly analogous to syscall sequences. "
            "Comes with train/test splits and binary labels."
        ),
        "how_to_map": (
            "Extract the 'event_id' column. Build a Hensel mapping similar to "
            "DEFAULT_SYSCALL_MAP. The dataset has ~8M events so you can tune "
            "your idle_fraction parameter against real idle event rates."
        ),
        "url": "https://www.kaggle.com/datasets/katehighnam/beth-dataset",
        "format": "CSV with columns: timestamp, pid, ppid, uid, event_id, ...",
        "size": "~1GB uncompressed",
        "caveat": (
            "Honeypot data — attackers know they may be monitored, "
            "so attack patterns may be noisier than in targeted intrusions."
        ),
    },

    "KDD_Cup_1999": {
        "what": (
            "Classic network intrusion dataset. Not syscall-based but very "
            "well-understood with published baselines from hundreds of papers."
        ),
        "why": (
            "Use this ONLY for calibration — to verify your evaluation pipeline "
            "is working correctly. If your model gets AUROC < 0.80 on KDD, "
            "something is wrong with your training loop, not the p-adic design."
        ),
        "how_to_map": (
            "Extract the discrete feature columns (protocol_type, service, flag). "
            "Map them to small integers and encode as Hensel digits. "
            "This is a proxy — KDD is not a sequence dataset."
        ),
        "url": "http://kdd.ics.uci.edu/databases/kddcup99/kddcup99.html",
        "format": "CSV",
        "size": "~700MB",
        "caveat": "Outdated and easy. Do not use as primary validation.",
    },

    "LANL_CERT": {
        "what": (
            "Los Alamos National Laboratory unified host and network logs. "
            "Contains authentication events, process events, network flows. "
            "Includes red team (attack) events with timestamps."
        ),
        "why": (
            "Best dataset for validating hardware bus sniffing because it contains "
            "process-level events that mirror what a hardware performance counter "
            "or bus analyzer would see. The red team events are the ground truth."
        ),
        "how_to_map": (
            "Use the process event log. Map process names/IDs to Hensel digits. "
            "Use the red team event timestamps to label windows. "
            "This is the closest publicly available analog to real hardware telemetry."
        ),
        "url": "https://csr.lanl.gov/data/cyber1/",
        "format": "Compressed CSV, multiple log types",
        "size": "~12GB compressed",
        "caveat": (
            "Requires registration. Very large — start with a 1-week slice. "
            "Attack events are sparse (~0.01% of all events), which matches "
            "your realistic attack_fraction target."
        ),
    },
}


def print_dataset_guide() -> None:
    print("\n" + "=" * 70)
    print("DATASET GUIDE FOR HARDWARE BUS ANOMALY DETECTION VALIDATION")
    print("=" * 70)
    for name, info in DATASET_GUIDE.items():
        print(f"\n{'─'*60}")
        print(f"  {name}")
        print(f"{'─'*60}")
        print(f"  WHAT:   {info['what'][:80]}...")
        print(f"  WHY:    {info['why'][:80]}...")
        print(f"  MAP:    {info['how_to_map'][:80]}...")
        print(f"  URL:    {info['url']}")
        print(f"  FORMAT: {info['format']}")
        print(f"  SIZE:   {info['size']}")
        print(f"  CAVEAT: {info['caveat'][:80]}...")
    print(f"\n{'='*70}")
    print("RECOMMENDED ORDER:")
    print("  1. ADFA-LD   — best structural fit, small, fast to iterate")
    print("  2. BETH      — modern, large, has real idle-cycle analog")
    print("  3. LANL_CERT — closest to hardware telemetry, sparse attacks")
    print("  4. KDD       — calibration only, do not use as primary result")
    print("=" * 70 + "\n")


# ---------------------------------------------------------------------------
# Minimal ADFA-LD loader
# ---------------------------------------------------------------------------

def load_adfa_ld(
    data_dir: str,
    syscall_map: dict[str, int] | None = None,
    p: int = 3,
    r: int = 8,
    window_size: int = 32,
    stride: int = 1,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Load ADFA-LD syscall traces and convert to Hensel digit windows.

    Expects data_dir to contain:
        Training_Data_Master/  — normal traces (one file per process)
        Attack_Data_Master/    — attack traces organized by attack family

    Each file is a space-separated sequence of syscall IDs (integers).

    Returns:
        windows: [N, window_size, r] int64 Hensel digits
        labels:  [N] float32, 0=normal, 1=attack
    """
    import os
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    from padic_transformer.hensel import int64_to_digits

    data_path = Path(data_dir)
    if not data_path.exists():
        raise FileNotFoundError(
            f"ADFA-LD data directory not found: {data_dir}\n"
            f"Download from: {DATASET_GUIDE['ADFA-LD']['url']}"
        )

    def read_trace(filepath: Path) -> list[int]:
        with open(filepath, "r") as f:
            return [int(x) for x in f.read().split() if x.strip().isdigit()]

    def trace_to_windows(
        syscall_ids: list[int],
        label: float,
    ) -> tuple[list[torch.Tensor], list[float]]:
        if len(syscall_ids) < window_size:
            return [], []
        # Map to Hensel digits
        ids_tensor = torch.tensor(syscall_ids, dtype=torch.int64)
        # Clamp to valid range for the given p and r
        max_val = p ** r - 1
        ids_clamped = ids_tensor.clamp(0, max_val)
        digit_seq = int64_to_digits(ids_clamped, p=p, r=r)  # [len, r]

        wins, labs = [], []
        for start in range(0, len(syscall_ids) - window_size + 1, stride):
            wins.append(digit_seq[start: start + window_size])
            labs.append(label)
        return wins, labs

    all_windows: list[torch.Tensor] = []
    all_labels: list[float] = []

    # Normal traces
    normal_dir = data_path / "Training_Data_Master"
    if normal_dir.exists():
        for filepath in sorted(normal_dir.glob("*.txt")):
            ids = read_trace(filepath)
            wins, labs = trace_to_windows(ids, label=0.0)
            all_windows.extend(wins)
            all_labels.extend(labs)
        print(f"Loaded {len(all_windows)} normal windows from {normal_dir}")

    # Attack traces
    attack_dir = data_path / "Attack_Data_Master"
    n_before = len(all_windows)
    if attack_dir.exists():
        for attack_family in sorted(attack_dir.iterdir()):
            if not attack_family.is_dir():
                continue
            for filepath in sorted(attack_family.glob("*.txt")):
                ids = read_trace(filepath)
                wins, labs = trace_to_windows(ids, label=1.0)
                all_windows.extend(wins)
                all_labels.extend(labs)
        print(f"Loaded {len(all_windows) - n_before} attack windows from {attack_dir}")

    if not all_windows:
        raise RuntimeError(
            f"No trace files found in {data_dir}. "
            "Expected subdirectories: Training_Data_Master/, Attack_Data_Master/"
        )

    windows_tensor = torch.stack(all_windows)     # [N, window_size, r]
    labels_tensor  = torch.tensor(all_labels, dtype=torch.float32)

    n_pos = int(labels_tensor.sum().item())
    n_neg = len(labels_tensor) - n_pos
    print(
        f"ADFA-LD: {len(labels_tensor)} windows | "
        f"normal={n_neg} attack={n_pos} "
        f"attack_rate={n_pos/len(labels_tensor)*100:.2f}%"
    )
    return windows_tensor, labels_tensor


if __name__ == "__main__":
    print_dataset_guide()
